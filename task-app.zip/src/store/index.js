// Nos permite importar los dos stores en la misma linea
export * from './auth'
export * from './task'
export * from './theme'