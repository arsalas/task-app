<template>
    <div class="error">
        <div class="title has-text-danger is-size-1">
            404 Pagina no encontrada
        </div>
    </div>
</template>
<script setup>
</script>
<style scoped>
.error {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>