<template>
    <div class="confirm-container">
        <article class="message is-success has-text-centered">
            <div class="message-body">
                <div class="title">
                    Muchas gracias por registrarte!!
                </div>
                <div class="subtitle">
                    En breve recibiras un email de validacion
                </div>
            </div>
        </article>
    </div>
</template>
<script setup>
</script>
<style scoped>
.confirm-container {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}
</style>